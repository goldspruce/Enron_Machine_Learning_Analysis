#!/usr/bin/python

### See .ipynb file for documentation ###
###

import sys
import pickle

import matplotlib.pyplot as plt

from sklearn import preprocessing
from sklearn import grid_search 
from time import time

from sklearn import svm
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn import cross_validation
from sklearn.cross_validation import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import StratifiedShuffleSplit, GridSearchCV
from sklearn.pipeline import Pipeline
sys.path.append("../tools/")

from feature_format import featureFormat, targetFeatureSplit
from tester import dump_classifier_and_data

from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2

### Task 1: Select what features you'll use.
### features_list is a list of strings, each of which is a feature name.
### The first feature must be "poi".
features_list = ['poi','salary','total_stock_value','exercised_stock_options','from_poi_to_this_person','from_this_person_to_poi','from_messages','to_messages','ratio_to_poi','ratio_from_poi','ratio_exercised']
# You will need to use more features, 8 existing features, 3 new ones I created

### Load the dictionary containing the dataset
with open("final_project_dataset.pkl", "r") as data_file:
    data_dict = pickle.load(data_file)

import pprint

features_list = ['poi','salary','total_stock_value','exercised_stock_options','from_poi_to_this_person','from_this_person_to_poi','from_messages','to_messages','ratio_to_poi','ratio_from_poi','ratio_exercised']

print len(data_dict)
print len(data_dict['ALLEN PHILLIP K'])

data_dict.pop('TOTAL', 0)
data_dict.pop('TRAVEL AGENCY IN THE PAR', 0)
data_dict.pop('LOCKHART EUGENE E', 0)
print "Three entries popped"
len(data_dict)

n=0
for each in data_dict:
    if data_dict[each]['poi']:
        n+=1
print n

def new_feature(numerator,denominator):
    new_feature=[]

    for i in data_dict:
        if data_dict[i][numerator]=="NaN" or data_dict[i][denominator]=="NaN":
            new_feature.append("NaN")
        elif data_dict[i][numerator]<0 or data_dict[i][denominator]<=0:
            new_feature.append("NaN")
        else:
            new_feature.append(float(data_dict[i][numerator]) / data_dict[i][denominator])
    return new_feature

### create lists of new features
ratio_exercised=new_feature("exercised_stock_options","total_stock_value")
ratio_to_poi=new_feature("from_poi_to_this_person","to_messages")
ratio_from_poi=new_feature("from_this_person_to_poi","from_messages")

### insert new features into data_dict
count=0
for i in data_dict:
    data_dict[i]["ratio_exercised"] = ratio_exercised[count]
    data_dict[i]["ratio_to_poi"] = ratio_to_poi[count]
    data_dict[i]["ratio_from_poi"] = ratio_from_poi[count]
    count +=1

### store to my_dataset for easy export below
my_dataset = data_dict

data = featureFormat(my_dataset, features_list, sort_keys = True)

labels, features = targetFeatureSplit(data)

n=0
for point in data:
    ratio_exercised = point[8]
    plt.scatter( n, ratio_exercised )
    n+=1
plt.xlabel("ratio exercised")
plt.show()

n=0
for point in data:
    ratio_to_poi  = point[9]
    if ratio_to_poi == 1.0:
        print point
    plt.scatter( n, ratio_to_poi )
    n+=1
plt.xlabel("ratio of all emails sent to POI")
plt.show()

n=0
for point in data:
    ratio_to_poi  = point[9]
    if ratio_to_poi == 1.0:
        print point
    plt.scatter( n, ratio_to_poi )
    n+=1
plt.xlabel("ratio of all emails sent to POI")
plt.show()

n=0
for point in data:
    ratio_from_poi  = point[10]
    plt.scatter( n, ratio_from_poi )
    n+=1
plt.xlabel("ratio of all from POI")
plt.show()

K_best = SelectKBest(k=5)
# Use that instance to extract the best features:
features_kbest = K_best.fit_transform(features, labels)
print "Shape of features after applying SelectKBest -> ", features_kbest.shape
print data_dict["ALLEN PHILLIP K"]
print features_kbest[0]
print features[0]
print data_dict["BANNANTINE JAMES M"]
print features_kbest[2]
print features[2]

features_train, features_test, labels_train, labels_test = cross_validation.train_test_split(features, labels, test_size=0.1, random_state=42)

def classify_NB(features_train, labels_train):
    
    ### your code goes here--should return a trained decision tree classifer
    
    clf = GaussianNB()
    clf.fit(features_train, labels_train)
    return clf
    
clf = classify_NB(features_train, labels_train)
pred = clf.predict(features_test)
print "NB: accuracy, precision, recall, F1"
print accuracy_score(pred,labels_test)
print precision_score(pred,labels_test)
print recall_score(pred,labels_test)
print f1_score(pred,labels_test)

def classify_DTC(features_train, labels_train):
    
    ### your code goes here--should return a trained decision tree classifer
    
    clf = DecisionTreeClassifier()
    clf.fit(features_train, labels_train)
    return clf
    
clf = classify_DTC(features_train, labels_train)
pred = clf.predict(features_test)
print "DTC: accuracy, precision, recall, F1"
print accuracy_score(pred,labels_test)
print precision_score(pred,labels_test)
print recall_score(pred,labels_test)
print f1_score(pred,labels_test)

def classify_knn(features_train,labels_train,n):
    neigh = KNeighborsClassifier(n)
    neigh.fit(features_train, labels_train)
    return neigh

def classit_knn(n):
    return classify_knn(features_train, labels_train, n)

def pred_knn(n):
    return classit_knn(n).predict(features_test)

pred_2 = accuracy_score(pred_knn(2),labels_test)
pred_5 = accuracy_score(pred_knn(5),labels_test)
pred_8 = accuracy_score(pred_knn(8),labels_test)
print "KNN: accuracy, precision, recall, F1"
print "n:2"
print round(pred_2,3)
print precision_score(pred_knn(2),labels_test)
print recall_score(pred_knn(2),labels_test)
print f1_score(pred_knn(2),labels_test)
print "n:5"
print round(pred_5,3)
print precision_score(pred_knn(5),labels_test)
print recall_score(pred_knn(5),labels_test)
print f1_score(pred_knn(5),labels_test)
print "n:8"
print round(pred_8,3)
print precision_score(pred_knn(8),labels_test)
print recall_score(pred_knn(8),labels_test)
print f1_score(pred_knn(8),labels_test)

knn =  KNeighborsClassifier()
scaler = MinMaxScaler()
select = SelectKBest(k=3)
 
sss = StratifiedShuffleSplit(n_splits = 100, random_state=42)

pipe = Pipeline(steps=[('scaling', scaler), ('feature_selection', select), ("knn", knn)])

param_grid = {"knn__n_neighbors": [1, 3, 5, 8, 10, 12, 14],
              "knn__algorithm": ["auto","ball_tree", "kd_tree", "brute"],
              "knn__leaf_size": range(3,10,1),
              "knn__p": [1,2]
             }

knnclf = GridSearchCV(pipe, param_grid, scoring='f1', cv=sss)
knnclf.fit(features, labels)
bestknn = knnclf.best_estimator_
print "Best KNN"
print bestknn

best = KNeighborsClassifier(algorithm='auto', leaf_size=3, metric='minkowski',
           metric_params=None, n_jobs=1, n_neighbors=1, p=2,
           weights='uniform')

best.fit(features_train, labels_train)
pred = best.predict(features_test)
print "KNN grid: accuracy, precision, recall, F1"
print accuracy_score(pred,labels_test)
print precision_score(pred,labels_test)
print recall_score(pred,labels_test)
print f1_score(pred,labels_test)

dtree =  DecisionTreeClassifier()
scaler = MinMaxScaler()
sss = StratifiedShuffleSplit(n_splits = 100, random_state=42)
select = SelectKBest(k=3)


pipe =  Pipeline(steps=[('scaling',scaler),('feature_selection', select), ("dt", dtree)])

param_grid = {"dt__criterion": ["entropy"],
              "dt__min_samples_split": [2, 4, 6],
              "dt__max_depth": [2, 4, 6],
              "dt__min_samples_leaf": [2, 4, 6],
              "dt__max_leaf_nodes": [2, 4, 6],
              }

dtcclf = GridSearchCV(pipe, param_grid, scoring='f1', cv=sss)
dtcclf.fit(features, labels)
bestclf = dtcclf.best_estimator_
print "Best DTC"
print bestclf

best = DecisionTreeClassifier(class_weight=None, criterion='entropy', max_depth=4,
            max_features=None, max_leaf_nodes=6, min_impurity_split=1e-07,
            min_samples_leaf=4, min_samples_split=2,
            min_weight_fraction_leaf=0.0, presort=False, random_state=None,
            splitter='best')

best.fit(features_train, labels_train)
pred = best.predict(features_test)
print "DTC grid: accuracy, precision, recall, F1"
print accuracy_score(pred,labels_test)
print precision_score(pred,labels_test)
print recall_score(pred,labels_test)
print f1_score(pred,labels_test)

CLF_PICKLE_FILENAME = "my_classifier.pkl"
DATASET_PICKLE_FILENAME = "my_dataset.pkl"
FEATURE_LIST_FILENAME = "my_feature_list.pkl"

def dump_classifier_and_data(clf, dataset, feature_list):
    with open(CLF_PICKLE_FILENAME, "w") as clf_outfile:
        pickle.dump(clf, clf_outfile)
    with open(DATASET_PICKLE_FILENAME, "w") as dataset_outfile:
        pickle.dump(dataset, dataset_outfile)
    with open(FEATURE_LIST_FILENAME, "w") as featurelist_outfile:
        pickle.dump(feature_list, featurelist_outfile)
        
dump_classifier_and_data(bestknn, data_dict, features_list)

with open("my_classifier.pkl", "r") as file:
    clf = pickle.load(file)
print clf

with open("my_dataset.pkl", "r") as file:
    data = pickle.load(file)
for person in data:
    print person, data[person]
    break

with open("my_feature_list.pkl", "r") as file:
    features = pickle.load(file)
print features